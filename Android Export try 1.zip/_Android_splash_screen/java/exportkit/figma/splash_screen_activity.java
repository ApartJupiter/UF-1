
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		splash_screen
	 *	@date 		Saturday 24th of February 2024 01:15:08 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;

public class splash_screen_activity extends Activity {

	
	private View _bg___splash_screen_ek2;
	private View bg;
	private ImageView mask_group;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);

		
		_bg___splash_screen_ek2 = (View) findViewById(R.id._bg___splash_screen_ek2);
		bg = (View) findViewById(R.id.bg);
		mask_group = (ImageView) findViewById(R.id.mask_group);
	
		
		//custom code goes here
	
	}
}
	
	